-- =====================================================================
--  WIT Connect — PostgreSQL Schema (MVP v1)
--  We Insure Things | phone + SMS + AI contact-center platform
--
--  Target: PostgreSQL 14+
--  Covers the section 12 data model plus the supporting tables the
--  Agent / Manager / Admin dashboards require (offices, ring groups,
--  routing rules, templates, AI prompts, consent tracking).
--
--  Conventions:
--    * UUID primary keys (gen_random_uuid)
--    * snake_case names, plural tables
--    * created_at / updated_at on mutable tables (updated_at auto-maintained)
--    * Twilio resource SIDs stored alongside native IDs
--    * Compliance fields baked in (SMS consent, recording consent,
--      retention windows, audit trail)
-- =====================================================================

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;  -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS citext;    -- case-insensitive email

-- ---------------------------------------------------------------------
--  ENUM TYPES
-- ---------------------------------------------------------------------
CREATE TYPE user_role          AS ENUM ('agent','supervisor','manager','admin');
CREATE TYPE user_presence      AS ENUM ('available','on_call','wrap_up','break','offline');
CREATE TYPE team_type          AS ENUM ('sales','service','commercial','language','skill');
CREATE TYPE phone_number_type  AS ENUM ('main','queue','agent_direct','outbound');
CREATE TYPE a2p_status         AS ENUM ('pending','in_review','verified','failed');
CREATE TYPE call_direction     AS ENUM ('inbound','outbound');
CREATE TYPE call_status        AS ENUM ('queued','ringing','in_progress','completed','missed','voicemail','failed','abandoned');
CREATE TYPE recording_consent  AS ENUM ('not_required','disclosed','declined');
CREATE TYPE retention_status   AS ENUM ('active','expired','legal_hold','deleted');
CREATE TYPE sentiment_label    AS ENUM ('positive','neutral','negative');
CREATE TYPE sms_direction      AS ENUM ('inbound','outbound');
CREATE TYPE sms_status         AS ENUM ('queued','sent','delivered','undelivered','failed','received');
CREATE TYPE sms_consent        AS ENUM ('pending','opted_in','opted_out');
CREATE TYPE thread_status      AS ENUM ('open','snoozed','closed');
CREATE TYPE voicemail_status   AS ENUM ('new','heard','assigned','completed');
CREATE TYPE task_status        AS ENUM ('open','in_progress','blocked','done','cancelled');
CREATE TYPE task_priority      AS ENUM ('low','medium','high');
CREATE TYPE flag_type          AS ENUM ('compliance','sentiment','cancellation','sales_opportunity','qa','keyword');
CREATE TYPE flag_risk          AS ENUM ('low','medium','high','opportunity');
CREATE TYPE flag_status        AS ENUM ('open','reviewed','escalated','dismissed');
CREATE TYPE audit_action       AS ENUM ('create','update','delete','view','export','login','access');

-- ---------------------------------------------------------------------
--  updated_at trigger helper
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- =====================================================================
--  ORG STRUCTURE
-- =====================================================================

CREATE TABLE offices (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name          TEXT NOT NULL,
  timezone      TEXT NOT NULL DEFAULT 'America/Phoenix',
  state         CHAR(2),                       -- for state-specific routing/consent
  address       TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE teams (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  office_id     UUID REFERENCES offices(id) ON DELETE SET NULL,
  name          TEXT NOT NULL,
  type          team_type NOT NULL,
  language      TEXT,                          -- e.g. 'es' for Spanish routing
  is_active     BOOLEAN NOT NULL DEFAULT true,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE users (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  office_id     UUID REFERENCES offices(id) ON DELETE SET NULL,
  email         CITEXT NOT NULL UNIQUE,        -- Google Workspace SSO identity
  full_name     TEXT NOT NULL,
  role          user_role NOT NULL DEFAULT 'agent',
  presence      user_presence NOT NULL DEFAULT 'offline',
  languages     TEXT[] NOT NULL DEFAULT '{en}',-- skills-based / Spanish routing
  twilio_worker_sid TEXT,                       -- TaskRouter worker, if used
  is_active     BOOLEAN NOT NULL DEFAULT true,
  last_seen_at  TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Many-to-many: users belong to multiple teams / skill groups
CREATE TABLE team_members (
  team_id       UUID NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  is_lead       BOOLEAN NOT NULL DEFAULT false,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (team_id, user_id)
);

-- =====================================================================
--  TELEPHONY CONFIG
-- =====================================================================

CREATE TABLE phone_numbers (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  office_id      UUID REFERENCES offices(id) ON DELETE SET NULL,
  e164           TEXT NOT NULL UNIQUE,          -- +14805550100
  label          TEXT,
  type           phone_number_type NOT NULL DEFAULT 'main',
  twilio_sid     TEXT UNIQUE,                   -- Twilio incoming phone number SID
  assigned_user_id UUID REFERENCES users(id) ON DELETE SET NULL,  -- agent direct line
  a2p_status     a2p_status NOT NULL DEFAULT 'pending',
  is_active      BOOLEAN NOT NULL DEFAULT true,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE ring_groups (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id        UUID REFERENCES teams(id) ON DELETE SET NULL,
  name           TEXT NOT NULL,
  strategy       TEXT NOT NULL DEFAULT 'round_robin', -- round_robin|simultaneous|skills
  no_answer_secs INT  NOT NULL DEFAULT 20,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE ring_group_members (
  ring_group_id  UUID NOT NULL REFERENCES ring_groups(id) ON DELETE CASCADE,
  user_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  priority       INT  NOT NULL DEFAULT 1,
  PRIMARY KEY (ring_group_id, user_id)
);

CREATE TABLE business_hours (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  office_id      UUID NOT NULL REFERENCES offices(id) ON DELETE CASCADE,
  day_of_week    INT  NOT NULL CHECK (day_of_week BETWEEN 0 AND 6), -- 0=Sun
  open_time      TIME,
  close_time     TIME,
  is_closed      BOOLEAN NOT NULL DEFAULT false,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (office_id, day_of_week)
);

-- Ordered routing rules: which inbound number goes where, under what condition
CREATE TABLE routing_rules (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone_number_id UUID NOT NULL REFERENCES phone_numbers(id) ON DELETE CASCADE,
  priority       INT  NOT NULL DEFAULT 1,       -- evaluated low -> high
  condition      JSONB NOT NULL DEFAULT '{}',   -- {hours:'business', language:'es', state:'AZ'}
  target_type    TEXT NOT NULL,                 -- ring_group|user|voicemail|forward|ivr
  target_id      UUID,                          -- ring_group/user id when applicable
  forward_e164   TEXT,                          -- failover number when target_type=forward
  is_active      BOOLEAN NOT NULL DEFAULT true,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =====================================================================
--  CUSTOMERS
-- =====================================================================

CREATE TABLE customers (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name          TEXT,
  primary_phone      TEXT,                      -- E.164
  email              CITEXT,
  state              CHAR(2),
  nowcerts_id        TEXT,                      -- external IDs for integrations
  agencyzoom_id      TEXT,
  sms_consent        sms_consent NOT NULL DEFAULT 'pending',
  sms_consent_at     TIMESTAMPTZ,
  do_not_call        BOOLEAN NOT NULL DEFAULT false,  -- TCPA / DNC tracking
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- A customer may have multiple numbers (cell, home, work)
CREATE TABLE customer_phones (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id   UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  e164          TEXT NOT NULL,
  kind          TEXT NOT NULL DEFAULT 'mobile', -- mobile|home|work
  is_primary    BOOLEAN NOT NULL DEFAULT false,
  UNIQUE (customer_id, e164)
);

-- =====================================================================
--  CALLS & RELATED ARTIFACTS
-- =====================================================================

CREATE TABLE dispositions (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code          TEXT NOT NULL UNIQUE,           -- 'quote','follow_up','docs_needed'
  label         TEXT NOT NULL,
  category      TEXT,                           -- sales|service|compliance
  sort_order    INT  NOT NULL DEFAULT 0,
  is_active     BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE calls (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  twilio_call_sid TEXT UNIQUE,
  direction       call_direction NOT NULL,
  status          call_status NOT NULL DEFAULT 'queued',
  from_e164       TEXT NOT NULL,
  to_e164         TEXT NOT NULL,
  phone_number_id UUID REFERENCES phone_numbers(id) ON DELETE SET NULL,
  agent_id        UUID REFERENCES users(id) ON DELETE SET NULL,
  team_id         UUID REFERENCES teams(id) ON DELETE SET NULL,
  customer_id     UUID REFERENCES customers(id) ON DELETE SET NULL,
  disposition_id  UUID REFERENCES dispositions(id) ON DELETE SET NULL,
  participants    JSONB NOT NULL DEFAULT '[]',  -- transfer legs / conference members
  tags            TEXT[] NOT NULL DEFAULT '{}',
  notes           TEXT,
  queued_at       TIMESTAMPTZ,
  answered_at     TIMESTAMPTZ,
  ended_at        TIMESTAMPTZ,
  wait_seconds    INT,                          -- queue hold time (for SLA)
  talk_seconds    INT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE call_recordings (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  call_id          UUID NOT NULL REFERENCES calls(id) ON DELETE CASCADE,
  twilio_recording_sid TEXT UNIQUE,
  storage_url      TEXT,                         -- S3 / GCS / R2 key
  duration_seconds INT,
  consent          recording_consent NOT NULL DEFAULT 'not_required',
  retention_status retention_status NOT NULL DEFAULT 'active',
  retention_until  DATE,                         -- e.g. now + 13 months
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE call_transcripts (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  call_id          UUID NOT NULL REFERENCES calls(id) ON DELETE CASCADE,
  provider         TEXT,                         -- twilio_ci|openai|deepgram
  language         TEXT NOT NULL DEFAULT 'en',
  full_text        TEXT,
  segments         JSONB NOT NULL DEFAULT '[]',  -- [{speaker,start,end,text}]
  confidence       NUMERIC(4,3),
  retention_until  DATE,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE call_summaries (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  call_id          UUID NOT NULL REFERENCES calls(id) ON DELETE CASCADE,
  summary          TEXT,
  action_items     JSONB NOT NULL DEFAULT '[]',  -- [{text, done}]
  next_steps       TEXT,
  sentiment        sentiment_label,
  qa_score         NUMERIC(4,1),                 -- 0-100
  model            TEXT,                         -- gpt-4.1, etc (provenance)
  is_human_reviewed BOOLEAN NOT NULL DEFAULT false, -- summaries are assistive only
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE voicemails (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  call_id          UUID REFERENCES calls(id) ON DELETE SET NULL,
  customer_id      UUID REFERENCES customers(id) ON DELETE SET NULL,
  from_e164        TEXT NOT NULL,
  storage_url      TEXT,
  duration_seconds INT,
  transcript       TEXT,
  status           voicemail_status NOT NULL DEFAULT 'new',
  assigned_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =====================================================================
--  SMS / MMS
-- =====================================================================

CREATE TABLE sms_threads (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id      UUID REFERENCES customers(id) ON DELETE SET NULL,
  customer_e164    TEXT NOT NULL,
  wit_phone_number_id UUID REFERENCES phone_numbers(id) ON DELETE SET NULL,
  assigned_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  team_id          UUID REFERENCES teams(id) ON DELETE SET NULL,
  status           thread_status NOT NULL DEFAULT 'open',
  last_message_at  TIMESTAMPTZ,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (customer_e164, wit_phone_number_id)
);

CREATE TABLE sms_messages (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id        UUID NOT NULL REFERENCES sms_threads(id) ON DELETE CASCADE,
  twilio_message_sid TEXT UNIQUE,
  direction        sms_direction NOT NULL,
  status           sms_status NOT NULL DEFAULT 'queued',
  body             TEXT,
  media_urls       TEXT[] NOT NULL DEFAULT '{}', -- MMS attachments
  sent_by_user_id  UUID REFERENCES users(id) ON DELETE SET NULL,
  is_automated     BOOLEAN NOT NULL DEFAULT false, -- text-back / auto-reply
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE sms_templates (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name          TEXT NOT NULL,
  body          TEXT NOT NULL,                  -- supports {name},{date},{policy}
  category      TEXT,                           -- service|marketing
  is_active     BOOLEAN NOT NULL DEFAULT true,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =====================================================================
--  TASKS, AI FLAGS, AI PROMPTS, AUDIT
-- =====================================================================

CREATE TABLE tasks (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title         TEXT NOT NULL,
  description   TEXT,
  status        task_status NOT NULL DEFAULT 'open',
  priority      task_priority NOT NULL DEFAULT 'medium',
  customer_id   UUID REFERENCES customers(id) ON DELETE SET NULL,
  call_id       UUID REFERENCES calls(id) ON DELETE SET NULL,
  assigned_to   UUID REFERENCES users(id) ON DELETE SET NULL,
  created_by    UUID REFERENCES users(id) ON DELETE SET NULL,
  is_compliance_block BOOLEAN NOT NULL DEFAULT false, -- e.g. missing signed app
  due_at        TIMESTAMPTZ,
  completed_at  TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE ai_flags (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  call_id       UUID REFERENCES calls(id) ON DELETE CASCADE,
  type          flag_type NOT NULL,
  risk          flag_risk NOT NULL DEFAULT 'medium',
  status        flag_status NOT NULL DEFAULT 'open',
  message       TEXT NOT NULL,
  keyword       TEXT,                           -- triggering keyword, if any
  agent_id      UUID REFERENCES users(id) ON DELETE SET NULL,
  reviewed_by   UUID REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at   TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE ai_prompts (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name          TEXT NOT NULL,
  trigger       TEXT,                           -- e.g. 'add_a_car','cancellation'
  body          TEXT NOT NULL,                  -- the prompt text / rules
  is_active     BOOLEAN NOT NULL DEFAULT true,
  version       INT  NOT NULL DEFAULT 1,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Immutable audit trail: who accessed/changed/exported sensitive records
CREATE TABLE audit_logs (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id      UUID REFERENCES users(id) ON DELETE SET NULL,
  action        audit_action NOT NULL,
  entity_type   TEXT NOT NULL,                  -- 'call_recording','customer', etc
  entity_id     UUID,
  changes       JSONB,                          -- before/after diff
  ip_address    INET,
  user_agent    TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =====================================================================
--  INDEXES (common dashboard query paths)
-- =====================================================================
CREATE INDEX idx_users_office          ON users(office_id);
CREATE INDEX idx_users_presence        ON users(presence) WHERE is_active;
CREATE INDEX idx_phone_numbers_office  ON phone_numbers(office_id);

CREATE INDEX idx_calls_agent_started   ON calls(agent_id, queued_at DESC);
CREATE INDEX idx_calls_customer        ON calls(customer_id);
CREATE INDEX idx_calls_team_status     ON calls(team_id, status);
CREATE INDEX idx_calls_status_started  ON calls(status, queued_at DESC); -- live/missed views
CREATE INDEX idx_calls_tags            ON calls USING GIN (tags);

CREATE INDEX idx_recordings_call       ON call_recordings(call_id);
CREATE INDEX idx_recordings_retention  ON call_recordings(retention_until) WHERE retention_status = 'active';
CREATE INDEX idx_transcripts_call      ON call_transcripts(call_id);
CREATE INDEX idx_summaries_call        ON call_summaries(call_id);

CREATE INDEX idx_voicemails_status     ON voicemails(status, created_at DESC);
CREATE INDEX idx_voicemails_assignee   ON voicemails(assigned_user_id);

CREATE INDEX idx_threads_assignee      ON sms_threads(assigned_user_id, status);
CREATE INDEX idx_threads_last_msg      ON sms_threads(last_message_at DESC);
CREATE INDEX idx_messages_thread       ON sms_messages(thread_id, created_at);

CREATE INDEX idx_tasks_assignee_status ON tasks(assigned_to, status);
CREATE INDEX idx_tasks_customer        ON tasks(customer_id);

CREATE INDEX idx_flags_status_created  ON ai_flags(status, created_at DESC);
CREATE INDEX idx_flags_type_risk       ON ai_flags(type, risk);

CREATE INDEX idx_audit_entity          ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_actor_time      ON audit_logs(actor_id, created_at DESC);

CREATE INDEX idx_customers_phone       ON customers(primary_phone);
CREATE INDEX idx_customers_nowcerts    ON customers(nowcerts_id);

-- =====================================================================
--  updated_at TRIGGERS
-- =====================================================================
CREATE TRIGGER trg_offices_updated      BEFORE UPDATE ON offices       FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_teams_updated        BEFORE UPDATE ON teams         FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_users_updated        BEFORE UPDATE ON users         FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_phone_numbers_updated BEFORE UPDATE ON phone_numbers FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_ring_groups_updated  BEFORE UPDATE ON ring_groups   FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_routing_rules_updated BEFORE UPDATE ON routing_rules FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_customers_updated    BEFORE UPDATE ON customers     FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_calls_updated        BEFORE UPDATE ON calls         FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_summaries_updated    BEFORE UPDATE ON call_summaries FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_voicemails_updated   BEFORE UPDATE ON voicemails    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_threads_updated      BEFORE UPDATE ON sms_threads   FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_templates_updated    BEFORE UPDATE ON sms_templates FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_tasks_updated        BEFORE UPDATE ON tasks         FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_flags_updated        BEFORE UPDATE ON ai_flags      FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_prompts_updated      BEFORE UPDATE ON ai_prompts    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- =====================================================================
--  SEED DATA (matches the Admin dashboard panels)
-- =====================================================================
INSERT INTO dispositions (code, label, category, sort_order) VALUES
  ('quote',         'Quote',                 'sales',      1),
  ('sale_closed',   'Sale closed',           'sales',      2),
  ('cross_sell',    'Cross-sell',            'sales',      3),
  ('follow_up',     'Follow-up',             'service',    4),
  ('docs_needed',   'Documentation needed',  'compliance', 5),
  ('cancellation',  'Cancellation request',  'service',    6),
  ('left_voicemail','Left voicemail',        'service',    7),
  ('no_answer',     'No answer',             'service',    8),
  ('wrong_number',  'Wrong number',          'service',    9);

INSERT INTO sms_templates (name, body, category) VALUES
  ('Missed-call text-back', 'Sorry we missed you at We Insure Things! Reply here and an agent will help. Reply STOP to opt out.', 'service'),
  ('After-hours auto-reply', 'Thanks for texting WIT. We''re open M-F 8a-6p. For claims, call your carrier''s 24/7 line.', 'service'),
  ('Proof of insurance', 'Hi {name}, your ID card is attached. Coverage effective {date}. Questions? Just reply.', 'service'),
  ('Renewal reminder', 'Hi {name}, your {policy} renews {date}. Want a quick review to check for savings?', 'marketing');

INSERT INTO ai_prompts (name, trigger, body) VALUES
  ('Add-a-Car workflow', 'add_a_car',
   'Prompt agent to collect VIN, listed drivers, garaging address, usage/mileage, coverage changes, and payment method. Require a signed application before issuing or declaring proof of insurance. Create a follow-up task if VIN, proof, or signature is missing. Recommend renters/home/umbrella/life cross-sell when appropriate.'),
  ('Cancellation / retention', 'cancellation',
   'Detect keywords: cancel, complaint, DOI, attorney, lawsuit, claim. Flag manager review if sentiment is negative. Prompt agent to ask the reason for cancellation, offer remarketing, and document replacement-coverage warnings. Create a retention task and call summary automatically.'),
  ('Cross-sell prompts', 'cross_sell',
   'Surface renters, homeowners, umbrella, and life opportunities based on conversation context (e.g., new teen driver, recent home purchase, monoline auto).'),
  ('Compliance documentation', 'compliance',
   'If proof of insurance is declared, require supporting documentation before issuing. If accident/violation data is scrubbed, require supporting documentation. If a signed application is missing, block the sales-credit workflow until completed. Store notes, summary, disposition, and documents to the customer record.');

COMMIT;

-- =====================================================================
--  END OF SCHEMA
-- =====================================================================
