import React, { useState, useMemo } from "react";

// ---------- WIT theme ----------
const C = {
  ink: "#06121D", ink2: "#0E2433", paper: "#F4F8FB", card: "#FFFFFF",
  line: "#E3EBF1", blue: "#00AEEF", deep: "#007EAE", green: "#33D17A",
  red: "#FF6868", mute: "#6B7280", faint: "#9AA7B2",
};
const FONTS = `
@import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,700;12..96,800&family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap');
.cc *{box-sizing:border-box}
.cc input[type=range]{-webkit-appearance:none;width:100%;height:5px;border-radius:99px;background:#DCE7EF;outline:none;accent-color:#00AEEF}
.cc input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:18px;height:18px;border-radius:50%;background:#00AEEF;cursor:pointer;border:3px solid #fff;box-shadow:0 1px 4px rgba(6,18,29,.25)}
.cc input[type=number]{font-family:'IBM Plex Mono',monospace;border:1px solid #E3EBF1;border-radius:9px;padding:7px 9px;font-size:13px;width:100%;color:#06121D}
.cc input[type=number]:focus{outline:none;border-color:#00AEEF}
@media (max-width:880px){.cc-grid{grid-template-columns:1fr !important}}
`;
const mono = { fontFamily: "'IBM Plex Mono', monospace" };
const usd = (n) => "$" + Math.round(n).toLocaleString("en-US");

// Section 8 build ranges (AI-assisted vs traditional dev shop)
const SCOPES = [
  { name: "Prototype", ai: [15000, 50000], trad: [40000, 100000] },
  { name: "Web MVP", ai: [50000, 150000], trad: [125000, 300000] },
  { name: "Web + SMS + AI", ai: [125000, 300000], trad: [300000, 700000] },
  { name: "Web + iOS + Android", ai: [250000, 600000], trad: [600000, 1200000] },
  { name: "Full Dialpad replacement", ai: [750000, 1800000], trad: [1500000, 3000000] },
];

// Section 9 "likely" monthly operating band
const BAND = { low: 8000, high: 35000 };

export default function CostCalculator() {
  // --- usage drivers ---
  const [agents, setAgents] = useState(12);
  const [callsPerDay, setCallsPerDay] = useState(28);
  const [workdays, setWorkdays] = useState(21);
  const [avgMin, setAvgMin] = useState(5);
  const [pctRecorded, setPctRecorded] = useState(100);
  const [pctTranscribed, setPctTranscribed] = useState(70);
  const [smsPerMonth, setSmsPerMonth] = useState(15000);
  const [mmsPerMonth, setMmsPerMonth] = useState(800);
  const [numbers, setNumbers] = useState(8);
  const [flexOn, setFlexOn] = useState(false);
  const [flexSeats, setFlexSeats] = useState(12);

  // --- fixed-ish monthly costs (editable) ---
  const [hosting, setHosting] = useState(1200);
  const [monitoring, setMonitoring] = useState(600);
  const [devSupport, setDevSupport] = useState(12000);

  // --- unit rate assumptions (editable; validate vs current Twilio pricing) ---
  const [r, setR] = useState({
    voice: 0.013, number: 1.15, sms: 0.01, mms: 0.02,
    record: 0.004, ai: 0.02, flexSeat: 150,
  });
  const setRate = (k, v) => setR((p) => ({ ...p, [k]: Number(v) || 0 }));

  // --- build scope ---
  const [scopeIdx, setScopeIdx] = useState(2);
  const [approach, setApproach] = useState("ai");

  const m = useMemo(() => {
    const totalMin = agents * callsPerDay * workdays * avgMin;
    const recordedMin = totalMin * (pctRecorded / 100);
    const transcribedMin = totalMin * (pctTranscribed / 100);
    const items = [
      { key: "Voice usage", val: totalMin * r.voice, color: C.blue },
      { key: "Phone numbers", val: numbers * r.number, color: "#5BC5EE" },
      { key: "SMS / MMS", val: smsPerMonth * r.sms + mmsPerMonth * r.mms, color: C.deep },
      { key: "Recording + storage", val: recordedMin * r.record, color: "#0A5980" },
      { key: "Transcription / AI", val: transcribedMin * r.ai, color: C.green },
      { key: "Twilio Flex", val: flexOn ? flexSeats * r.flexSeat : 0, color: "#2E9E6B" },
      { key: "Hosting / database", val: hosting, color: C.mute },
      { key: "Monitoring / security", val: monitoring, color: C.faint },
      { key: "Developer support", val: devSupport, color: C.ink },
    ];
    const total = items.reduce((s, i) => s + i.val, 0);
    return { totalMin, recordedMin, transcribedMin, items, total };
  }, [agents, callsPerDay, workdays, avgMin, pctRecorded, pctTranscribed,
      smsPerMonth, mmsPerMonth, numbers, flexOn, flexSeats, hosting,
      monitoring, devSupport, r]);

  const scope = SCOPES[scopeIdx];
  const [bLow, bHigh] = approach === "ai" ? scope.ai : scope.trad;
  const buildMid = (bLow + bHigh) / 2;
  const tco12 = buildMid + m.total * 12;

  // gauge position of monthly estimate within (extended) band
  const gMin = 0, gMax = Math.max(BAND.high * 1.15, m.total * 1.1);
  const pos = Math.min(100, Math.max(0, (m.total / gMax) * 100));
  const bandL = (BAND.low / gMax) * 100, bandR = (BAND.high / gMax) * 100;

  return (
    <div className="cc" style={{ fontFamily: "'IBM Plex Sans',sans-serif", background: C.paper, minHeight: "100vh", color: C.ink, padding: "26px 18px" }}>
      <style>{FONTS}</style>
      <div style={{ maxWidth: 1040, margin: "0 auto" }}>
        {/* header */}
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 6 }}>
          <div style={{ width: 38, height: 38, borderRadius: 11, background: C.blue, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontFamily: "'Bricolage Grotesque'", fontSize: 18 }}>W</div>
          <div>
            <h1 style={{ margin: 0, fontSize: 24, fontFamily: "'Bricolage Grotesque'", fontWeight: 700 }}>WIT Connect — Cost Calculator</h1>
            <div style={{ fontSize: 12.5, color: C.mute }}>Flex the drivers below to estimate monthly operating cost and total cost of ownership.</div>
          </div>
        </div>

        <div className="cc-grid" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18, marginTop: 18 }}>
          {/* INPUTS */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <Panel title="Team & call volume">
              <Slider label="Agents" v={agents} set={setAgents} min={1} max={100} />
              <Slider label="Calls / agent / day" v={callsPerDay} set={setCallsPerDay} min={1} max={80} />
              <Slider label="Working days / month" v={workdays} set={setWorkdays} min={15} max={26} />
              <Slider label="Avg call length (min)" v={avgMin} set={setAvgMin} min={1} max={20} />
              <Mini>{usd(0).slice(0,0)}{(m.totalMin).toLocaleString()} talk-minutes / month</Mini>
            </Panel>

            <Panel title="AI & recording">
              <Slider label="% of calls recorded" v={pctRecorded} set={setPctRecorded} min={0} max={100} suffix="%" />
              <Slider label="% transcribed / AI-summarized" v={pctTranscribed} set={setPctTranscribed} min={0} max={100} suffix="%" />
              <Mini>Transcribing {(m.transcribedMin).toLocaleString()} min — the biggest cost lever</Mini>
            </Panel>

            <Panel title="Messaging & numbers">
              <NumRow label="SMS segments / month" v={smsPerMonth} set={setSmsPerMonth} />
              <NumRow label="MMS / month" v={mmsPerMonth} set={setMmsPerMonth} />
              <NumRow label="Phone numbers" v={numbers} set={setNumbers} />
            </Panel>

            <Panel title="Platform & people">
              <Toggle label="Use Twilio Flex" on={flexOn} set={setFlexOn} />
              {flexOn && <NumRow label="Flex named seats" v={flexSeats} set={setFlexSeats} />}
              <NumRow label="Hosting / database ($/mo)" v={hosting} set={setHosting} />
              <NumRow label="Monitoring / security ($/mo)" v={monitoring} set={setMonitoring} />
              <NumRow label="Developer support ($/mo)" v={devSupport} set={setDevSupport} />
            </Panel>

            <Details summary="Unit rate assumptions (validate vs current Twilio pricing)">
              <RateRow label="Voice $/min" k="voice" r={r} set={setRate} step="0.001" />
              <RateRow label="Number $/mo" k="number" r={r} set={setRate} step="0.05" />
              <RateRow label="SMS $/segment" k="sms" r={r} set={setRate} step="0.001" />
              <RateRow label="MMS $/msg" k="mms" r={r} set={setRate} step="0.001" />
              <RateRow label="Recording+storage $/min" k="record" r={r} set={setRate} step="0.001" />
              <RateRow label="Transcription+AI $/min" k="ai" r={r} set={setRate} step="0.005" />
              <RateRow label="Flex $/seat/mo" k="flexSeat" r={r} set={setRate} step="5" />
            </Details>
          </div>

          {/* RESULTS */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <Panel>
              <div style={{ fontSize: 12.5, color: C.mute, fontWeight: 600 }}>Estimated monthly operating cost</div>
              <div style={{ fontSize: 44, fontWeight: 700, fontFamily: "'Bricolage Grotesque'", color: C.ink, lineHeight: 1.1, ...mono }}>{usd(m.total)}</div>

              {/* band gauge */}
              <div style={{ marginTop: 16, position: "relative", height: 34 }}>
                <div style={{ position: "absolute", top: 12, left: 0, right: 0, height: 8, borderRadius: 99, background: "#E3EBF1" }} />
                <div style={{ position: "absolute", top: 12, left: `${bandL}%`, width: `${bandR - bandL}%`, height: 8, borderRadius: 99, background: "#CDEBF8" }} />
                <div style={{ position: "absolute", top: 6, left: `calc(${pos}% - 1px)`, width: 3, height: 20, borderRadius: 2, background: C.blue }} />
                <div style={{ position: "absolute", top: 24, left: `${bandL}%`, fontSize: 10.5, color: C.faint, ...mono }}>{usd(BAND.low)}</div>
                <div style={{ position: "absolute", top: 24, left: `${bandR}%`, transform: "translateX(-100%)", fontSize: 10.5, color: C.faint, ...mono }}>{usd(BAND.high)}</div>
              </div>
              <div style={{ fontSize: 11.5, color: C.mute, marginTop: 4 }}>
                Plan's likely band is {usd(BAND.low)}–{usd(BAND.high)}/mo. {m.total < BAND.low ? "You're below it — a lean build." : m.total > BAND.high ? "You're above it — driven by AI or support spend." : "You're inside it."}
              </div>
            </Panel>

            <Panel title="Monthly breakdown">
              <div style={{ display: "flex", height: 18, borderRadius: 99, overflow: "hidden", marginBottom: 14 }}>
                {m.items.filter(i => i.val > 0).map((i) => (
                  <div key={i.key} title={i.key} style={{ width: `${(i.val / m.total) * 100}%`, background: i.color }} />
                ))}
              </div>
              {m.items.map((i) => (
                <div key={i.key} style={{ display: "flex", alignItems: "center", gap: 9, padding: "5px 0", fontSize: 13 }}>
                  <span style={{ width: 10, height: 10, borderRadius: 3, background: i.color, flexShrink: 0 }} />
                  <span style={{ color: C.ink }}>{i.key}</span>
                  <span style={{ flex: 1, borderBottom: `1px dotted ${C.line}`, margin: "0 6px", transform: "translateY(-3px)" }} />
                  <span style={{ fontWeight: 600, ...mono }}>{usd(i.val)}</span>
                </div>
              ))}
            </Panel>

            <Panel title="One-time build">
              <select value={scopeIdx} onChange={(e) => setScopeIdx(Number(e.target.value))}
                style={{ width: "100%", padding: "9px 10px", borderRadius: 9, border: `1px solid ${C.line}`, fontSize: 13, color: C.ink, marginBottom: 10, background: "#fff" }}>
                {SCOPES.map((s, i) => <option key={s.name} value={i}>{s.name}</option>)}
              </select>
              <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
                {[["ai", "AI-assisted"], ["trad", "Traditional dev shop"]].map(([k, l]) => (
                  <button key={k} onClick={() => setApproach(k)}
                    style={{ flex: 1, padding: "9px 0", borderRadius: 9, border: "none", cursor: "pointer", fontWeight: 600, fontSize: 12.5,
                      background: approach === k ? C.ink : "#EEF4F8", color: approach === k ? "#fff" : C.mute }}>{l}</button>
                ))}
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, padding: "5px 0" }}>
                <span style={{ color: C.mute }}>Build range</span>
                <span style={{ fontWeight: 700, ...mono }}>{usd(bLow)} – {usd(bHigh)}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, padding: "5px 0", borderTop: `1px solid ${C.line}` }}>
                <span style={{ color: C.mute }}>12-mo TCO (build mid + 12× monthly)</span>
                <span style={{ fontWeight: 700, color: C.deep, ...mono }}>{usd(tco12)}</span>
              </div>
              <div style={{ fontSize: 11, color: C.faint, marginTop: 10, lineHeight: 1.5 }}>
                Estimates only. Twilio and vendor pricing change frequently — validate every figure before committing, registering, or porting, exactly as the WIT Connect plan advises.
              </div>
            </Panel>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- input components ----------
function Panel({ title, children }) {
  return (
    <div style={{ background: C.card, border: `1px solid ${C.line}`, borderRadius: 16, padding: 18 }}>
      {title && <div style={{ fontWeight: 700, fontSize: 12.5, letterSpacing: ".04em", textTransform: "uppercase", color: C.ink, marginBottom: 14 }}>{title}</div>}
      {children}
    </div>
  );
}
function Slider({ label, v, set, min, max, suffix = "" }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 6 }}>
        <span style={{ color: C.mute }}>{label}</span>
        <span style={{ fontWeight: 700, ...mono }}>{v}{suffix}</span>
      </div>
      <input type="range" min={min} max={max} value={v} onChange={(e) => set(Number(e.target.value))} />
    </div>
  );
}
function NumRow({ label, v, set }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
      <span style={{ fontSize: 13, color: C.mute, flex: 1 }}>{label}</span>
      <div style={{ width: 110 }}>
        <input type="number" min={0} value={v} onChange={(e) => set(Number(e.target.value))} />
      </div>
    </div>
  );
}
function RateRow({ label, k, r, set, step }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 9 }}>
      <span style={{ fontSize: 12.5, color: C.mute, flex: 1 }}>{label}</span>
      <div style={{ width: 100 }}>
        <input type="number" min={0} step={step} value={r[k]} onChange={(e) => set(k, e.target.value)} />
      </div>
    </div>
  );
}
function Toggle({ label, on, set }) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
      <span style={{ fontSize: 13, color: C.ink, fontWeight: 600 }}>{label}</span>
      <button onClick={() => set(!on)} style={{ width: 44, height: 24, borderRadius: 99, border: "none", cursor: "pointer", background: on ? C.blue : "#CBD5DD", position: "relative", transition: "background .15s" }}>
        <span style={{ position: "absolute", top: 2, left: on ? 22 : 2, width: 20, height: 20, borderRadius: 99, background: "#fff", transition: "left .15s", boxShadow: "0 1px 3px rgba(0,0,0,.2)" }} />
      </button>
    </div>
  );
}
function Mini({ children }) {
  return <div style={{ fontSize: 11.5, color: C.deep, ...mono, background: "#EAF6FC", padding: "7px 10px", borderRadius: 8 }}>{children}</div>;
}
function Details({ summary, children }) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ background: C.card, border: `1px solid ${C.line}`, borderRadius: 16, padding: 18 }}>
      <button onClick={() => setOpen(!open)} style={{ width: "100%", textAlign: "left", border: "none", background: "none", cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center", padding: 0, fontFamily: "inherit" }}>
        <span style={{ fontWeight: 700, fontSize: 12.5, color: C.ink }}>{summary}</span>
        <span style={{ color: C.blue, fontWeight: 700, ...mono }}>{open ? "−" : "+"}</span>
      </button>
      {open && <div style={{ marginTop: 14 }}>{children}</div>}
    </div>
  );
}
