import { Router } from "express";
import { generateVoiceToken } from "../twilio.js";
import { config } from "../config.js";

export const tokenRouter = Router();

// GET /token?identity=marisol.vega
// In production, derive identity from the authenticated user (SSO) instead
// of trusting a query param.
tokenRouter.get("/token", (req, res) => {
  const identity = (req.query.identity || config.defaultAgentIdentity).toString();
  try {
    const token = generateVoiceToken(identity);
    res.json({ identity, token });
  } catch (err) {
    console.error("token error:", err.message);
    res.status(500).json({ error: "Could not mint token. Check Twilio env vars." });
  }
});
