import express from "express";
import cors from "cors";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { config } from "./config.js";
import { tokenRouter } from "./routes/token.js";
import { voiceRouter } from "./routes/voice.js";
import { recordingRouter } from "./routes/recording.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
app.use(cors());
app.use(express.urlencoded({ extended: false })); // Twilio posts form-encoded
app.use(express.json());

// Serve the browser softphone at /softphone.html
app.use(express.static(path.join(__dirname, "..", "public")));

app.get("/health", (_req, res) => res.json({ ok: true }));

app.use(tokenRouter);
app.use(voiceRouter);
app.use(recordingRouter);

app.listen(config.port, () => {
  console.log(`\u260E\uFE0F  WIT Connect telephony running on http://localhost:${config.port}`);
  console.log(`   Softphone:  http://localhost:${config.port}/softphone.html`);
  if (!config.publicBaseUrl) {
    console.log("   \u26A0\uFE0F  PUBLIC_BASE_URL is empty \u2014 webhooks/recordings need a public URL (use ngrok).");
  }
});
