# WIT Connect — API Route Map (v1)

The contract between the WIT Connect dashboards (Agent / Manager / Admin) and the
backend. Every route maps to tables in `wit_connect_schema.sql`; the Twilio
webhook routes are the ones already implemented in `wit-connect-telephony`.

---

## Conventions

| Topic | Rule |
| --- | --- |
| Base URL | `/api/v1` |
| Auth | `Authorization: Bearer <jwt>` — JWT minted after Google Workspace SSO. Telephony webhooks are exempt (Twilio-signature validated instead). |
| Roles | `agent`, `supervisor`, `manager`, `admin` (see RBAC matrix). |
| Format | JSON request/response; UTF-8; timestamps ISO 8601 UTC. |
| Errors | `{ "error": { "code": "string", "message": "string", "details"?: {} } }` with appropriate 4xx/5xx. |
| Pagination | `?limit=` (default 25, max 100) + `?cursor=`; response `{ "data": [...], "next_cursor": "string\|null" }`. |
| Filtering | List endpoints accept documented query params; unknown params are ignored. |
| Idempotency | POSTs that trigger telephony/SMS accept `Idempotency-Key` header. |
| Real-time | Live updates over WebSocket at `/ws` (see §10), not by polling. |

RBAC is enforced server-side per route. `agent` sees only their own calls/threads/
tasks unless a route says otherwise; `manager`/`admin` see office-wide.

---

## 1. Session & presence

| Method | Path | Role | Purpose | Tables |
| --- | --- | --- | --- | --- |
| GET | `/me` | any | Current user, role, office, presence. | users |
| PATCH | `/me/presence` | any | Set presence. | users |

```
PATCH /me/presence
{ "presence": "available" }        // available|on_call|wrap_up|break|offline
-> 200 { "id": "...", "presence": "available", "updated_at": "..." }
```

---

## 2. Voice & calls  → Agent + Manager dashboards

| Method | Path | Role | Purpose | Tables |
| --- | --- | --- | --- | --- |
| GET | `/voice/token` | agent+ | Mint browser Voice SDK token for this user. | — |
| POST | `/calls` | agent+ | Place an outbound call (server-side REST dial). | calls |
| GET | `/calls` | agent (own) / manager (all) | List + filter call history. | calls |
| GET | `/calls/:id` | owner/manager | Call detail incl. linked customer + disposition. | calls |
| PATCH | `/calls/:id` | owner/manager | Set disposition, tags, notes. | calls, dispositions |
| POST | `/calls/:id/transfer` | agent+ | Warm or blind transfer. | calls |
| POST | `/calls/:id/monitor` | supervisor+ | Listen / whisper / barge into a live call. | calls, audit_logs |
| GET | `/calls/:id/recording` | manager+ | Signed URL + recording metadata. | call_recordings, audit_logs |
| GET | `/calls/:id/transcript` | manager+ | Transcript text + segments. | call_transcripts |
| GET | `/calls/:id/summary` | owner/manager | AI summary, action items, QA, sentiment. | call_summaries |

```
POST /calls
{ "to": "+16025550147", "customer_id": "uuid?" }
-> 201 { "id": "uuid", "twilio_call_sid": "CA...", "status": "queued" }

GET /calls?status=missed&from=2026-05-31T00:00:00Z&team=sales&limit=25
-> 200 { "data": [ { "id","direction","status","from_e164","to_e164",
                     "customer": {...}, "queued_at","talk_seconds" } ], "next_cursor": null }

PATCH /calls/:id
{ "disposition_code": "docs_needed", "tags": ["add-a-car"], "notes": "..." }

POST /calls/:id/monitor
{ "mode": "whisper" }               // listen|whisper|barge  (writes an audit_log)
```

---

## 3. Customers

| Method | Path | Role | Purpose | Tables |
| --- | --- | --- | --- | --- |
| GET | `/customers` | agent+ | Search by name/phone/email/external ID. | customers |
| GET | `/customers/:id` | agent+ | Profile incl. phones + consent. | customers, customer_phones |
| POST | `/customers` | agent+ | Create. | customers |
| PATCH | `/customers/:id` | agent+ | Update incl. SMS consent, do-not-call. | customers |
| GET | `/customers/:id/timeline` | agent+ | Unified calls + SMS + voicemails + tasks. | (joins) |

```
GET /customers?search=castillo
-> 200 { "data": [ { "id","full_name","primary_phone","sms_consent",
                     "nowcerts_id","agencyzoom_id" } ], "next_cursor": null }
```

---

## 4. SMS / MMS  → Agent shared inbox

| Method | Path | Role | Purpose | Tables |
| --- | --- | --- | --- | --- |
| GET | `/sms/threads` | agent (assigned) / manager (all) | Shared inbox list. | sms_threads |
| GET | `/sms/threads/:id` | owner/manager | Thread header. | sms_threads |
| GET | `/sms/threads/:id/messages` | owner/manager | Messages (paginated). | sms_messages |
| POST | `/sms/threads/:id/messages` | agent+ | Send a message/MMS. | sms_messages |
| POST | `/sms/threads` | agent+ | Start a new thread. | sms_threads, sms_messages |
| PATCH | `/sms/threads/:id` | agent+ | Assign / set status (open/snoozed/closed). | sms_threads |
| GET | `/sms/templates` | agent+ | Active templates for quick replies. | sms_templates |

```
POST /sms/threads/:id/messages
{ "body": "Sending your e-sign link now.", "media_urls": [], "template_id": "uuid?" }
-> 201 { "id","twilio_message_sid","direction":"outbound","status":"queued" }
// Server checks customers.sms_consent != 'opted_out' before sending; 409 if blocked.
```

---

## 5. Voicemails

| Method | Path | Role | Purpose | Tables |
| --- | --- | --- | --- | --- |
| GET | `/voicemails` | agent (assigned) / manager (all) | Filter by status/assignee. | voicemails |
| GET | `/voicemails/:id` | owner/manager | Detail + transcript + signed audio URL. | voicemails |
| PATCH | `/voicemails/:id` | agent+ | Update status / reassign. | voicemails |

---

## 6. Tasks  → Agent action items, compliance blocks

| Method | Path | Role | Purpose | Tables |
| --- | --- | --- | --- | --- |
| GET | `/tasks` | agent (own) / manager (all) | Filter by status/assignee/customer. | tasks |
| POST | `/tasks` | agent+ | Create follow-up / documentation task. | tasks |
| PATCH | `/tasks/:id` | owner/manager | Update status, priority, assignee, due date. | tasks |

> A task with `is_compliance_block = true` gates the sales-credit workflow until
> resolved (e.g. missing signed application).

---

## 7. AI engine  → Agent summaries, Manager flag feed

| Method | Path | Role | Purpose | Tables |
| --- | --- | --- | --- | --- |
| GET | `/ai/flags` | manager+ | Compliance + sales-opportunity feed. | ai_flags |
| PATCH | `/ai/flags/:id` | manager+ | Review / escalate / dismiss. | ai_flags, audit_logs |
| POST | `/ai/analyze` | service token | Pipeline hook: run post-call analysis for a call. | call_summaries, ai_flags, tasks |
| GET | `/calls/:id/assist` | agent (own) | Live nudges for an in-progress call (or via WS). | — |

```
GET /ai/flags?status=open&type=compliance
-> 200 { "data": [ { "id","type":"compliance","risk":"high","message":"...",
                     "agent": {...}, "call_id","created_at" } ], "next_cursor": null }

PATCH /ai/flags/:id
{ "status": "reviewed" }            // reviewed|escalated|dismissed
```

---

## 8. Metrics & reporting  → Manager dashboard

| Method | Path | Role | Purpose | Source |
| --- | --- | --- | --- | --- |
| GET | `/metrics/realtime` | manager+ | Calls today, missed, active, avg answer. | calls |
| GET | `/metrics/queues` | manager+ | Per-queue waiting count, longest hold, SLA %. | calls, teams |
| GET | `/agents/presence` | manager+ | Wallboard: every agent's live status. | users |
| GET | `/metrics/sla` | manager+ | SLA over a date range. | calls |

```
GET /metrics/realtime
-> 200 { "calls_today": 318, "missed": 14, "active": 9, "avg_answer_sec": 18 }
```

---

## 9. Admin configuration  → Admin dashboard

All require `admin` (config) or `manager` (read), and every mutation writes an
`audit_logs` row.

| Resource | Routes | Tables |
| --- | --- | --- |
| Users | `GET/POST /admin/users`, `PATCH /admin/users/:id` | users |
| Teams | `GET/POST /admin/teams`, `PATCH /admin/teams/:id`, `POST/DELETE /admin/teams/:id/members` | teams, team_members |
| Phone numbers | `GET/POST /admin/phone-numbers`, `PATCH /admin/phone-numbers/:id` | phone_numbers |
| Ring groups | `GET/POST /admin/ring-groups`, `PATCH /admin/ring-groups/:id`, members CRUD | ring_groups, ring_group_members |
| Business hours | `GET/PUT /admin/offices/:id/business-hours` | business_hours |
| Routing rules | `GET/POST /admin/routing-rules`, `PATCH/DELETE /admin/routing-rules/:id` | routing_rules |
| SMS templates | `GET/POST /admin/sms-templates`, `PATCH /admin/sms-templates/:id` | sms_templates |
| AI prompts | `GET/POST /admin/ai-prompts`, `PATCH /admin/ai-prompts/:id` | ai_prompts |
| Dispositions | `GET/POST /admin/dispositions`, `PATCH /admin/dispositions/:id` | dispositions |
| Recording settings | `GET/PUT /admin/settings/recording` | (settings) |
| Audit logs | `GET /admin/audit-logs?entity=&actor=&range=` | audit_logs |

---

## 10. WebSocket events (`/ws`)

Client authenticates with the same bearer token, then subscribes to channels.

```
-> { "action": "subscribe", "channels": ["presence", "queues", "flags", "thread:UUID"] }
```

Server → client events:

| Event | Payload | Consumed by |
| --- | --- | --- |
| `call.ringing` | `{ call_id, from, customer }` | Agent (incoming) |
| `call.updated` | `{ call_id, status, talk_seconds }` | Agent, Manager |
| `presence.updated` | `{ user_id, presence }` | Manager wallboard |
| `queue.updated` | `{ queue, waiting, longest_sec, sla }` | Manager queues |
| `metrics.tick` | realtime KPI snapshot | Manager KPIs |
| `sms.message.created` | `{ thread_id, message }` | Agent inbox |
| `voicemail.created` | `{ voicemail }` | Agent, Manager |
| `flag.created` | `{ flag }` | Manager flag feed |
| `assist.nudge` | `{ call_id, nudges[] }` | Agent live-assist |

---

## 11. Telephony webhooks (Twilio → backend)

Server-to-server, **not** part of the client API. Twilio-signature validated,
no user auth. These are implemented in `wit-connect-telephony`.

| Method | Path | Fires on | Writes |
| --- | --- | --- | --- |
| POST | `/voice/outbound` | Browser SDK outbound (TwiML App URL) | calls |
| POST | `/voice/inbound` | Inbound to a WIT number | calls |
| POST | `/voice/dial-status` | `<Dial>` completes (voicemail fallback) | — |
| POST | `/voice/status` | Per-leg status callback | calls (status/timestamps) |
| POST | `/recording/status` | Recording completed | call_recordings |

> Production hardening: validate `X-Twilio-Signature` on every webhook, terminate
> SSO-issued JWTs at the gateway, and rate-limit `/calls` and SMS send endpoints.
```
