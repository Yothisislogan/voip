import React, { useState, useEffect, useRef } from "react";
import {
  Phone, PhoneIncoming, PhoneOutgoing, PhoneMissed, PhoneCall,
  MessageSquare, Voicemail, Mic, MicOff, Grid3x3, Pause, ArrowRightLeft,
  Users, Shield, Headphones, Activity, AlertTriangle, TrendingUp,
  CheckCircle2, Circle, Clock, Settings, Hash, Building2, Languages,
  Sparkles, FileText, ChevronRight, Star, Search, Bell, Volume2, UserCheck,
} from "lucide-react";

// ---------- Theme ----------
const C = {
  ink: "#06121D",        // Ink / Navy Black
  ink2: "#0E2433",       // lighter navy for gradients
  paper: "#F4F8FB",      // soft background
  card: "#FFFFFF",
  line: "#E3EBF1",       // cool border
  teal: "#00AEEF",       // WIT Blue (primary accent / CTA / connected)
  tealSoft: "#E2F4FC",   // soft WIT Blue tint
  green: "#33D17A",      // success / available
  amber: "#007EAE",      // Deep WIT Blue (opportunity / in-progress)
  amberSoft: "#E2F4FC",
  red: "#FF6868",        // alert / compliance risk
  redSoft: "#FFECEC",
  mute: "#6B7280",       // muted text
  faint: "#9AA7B2",
};

const FONTS = `
@import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,600;12..96,700;12..96,800&family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap');
@keyframes pulse{0%{box-shadow:0 0 0 0 rgba(51,209,122,.45)}70%{box-shadow:0 0 0 7px rgba(51,209,122,0)}100%{box-shadow:0 0 0 0 rgba(51,209,122,0)}}
@keyframes ringpulse{0%{box-shadow:0 0 0 0 rgba(0,174,239,.4)}70%{box-shadow:0 0 0 16px rgba(0,174,239,0)}100%{box-shadow:0 0 0 0 rgba(0,174,239,0)}}
@keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
@keyframes shimmer{0%{opacity:.5}50%{opacity:1}100%{opacity:.5}}
.wc *{box-sizing:border-box}
.wc-fade{animation:fadeUp .5s cubic-bezier(.2,.7,.3,1) both}
.wc-btn{cursor:pointer;border:none;font-family:inherit;transition:transform .12s ease, filter .12s ease}
.wc-btn:hover{filter:brightness(1.05)}
.wc-btn:active{transform:scale(.97)}
.wc-nav:hover{background:rgba(255,255,255,.07)}
.wc-row:hover{background:#FAF9F4}
.wc-scroll::-webkit-scrollbar{width:8px;height:8px}
.wc-scroll::-webkit-scrollbar-thumb{background:#D9D4C7;border-radius:8px}
`;

// ---------- Mock data ----------
const AGENTS = [
  { n: "Marisol Vega", t: "Sales", s: "oncall", dur: "4:12", lang: "EN/ES" },
  { n: "Derek Cole", t: "Service", s: "available", lang: "EN" },
  { n: "Priya Nair", t: "Commercial", s: "oncall", dur: "11:38", lang: "EN" },
  { n: "Tomás Reyes", t: "Sales", s: "available", lang: "EN/ES" },
  { n: "Janelle Brooks", t: "Service", s: "wrapup", lang: "EN" },
  { n: "Kevin Park", t: "Commercial", s: "break", lang: "EN" },
  { n: "Aisha Khan", t: "Service", s: "available", lang: "EN" },
  { n: "Luis Ortega", t: "Sales", s: "offline", lang: "EN/ES" },
];

const QUEUES = [
  { name: "Sales", waiting: 2, longest: "0:41", sla: 96, color: C.green },
  { name: "Service", waiting: 5, longest: "2:18", sla: 81, color: C.red },
  { name: "Commercial", waiting: 1, longest: "0:12", sla: 99, color: C.green },
  { name: "Español", waiting: 3, longest: "1:55", sla: 88, color: C.teal },
];

const FLAGS = [
  { type: "compliance", who: "Janelle B.", txt: "Proof of insurance declared before document upload", risk: "high", min: "2m" },
  { type: "sales", who: "Marisol V.", txt: "Customer mentioned new teen driver — auto + umbrella cross-sell", risk: "opp", min: "6m" },
  { type: "compliance", who: "Priya N.", txt: "Keyword detected: \u201Ccancel\u201D + \u201Cattorney\u201D \u2014 retention review", risk: "high", min: "14m" },
  { type: "sales", who: "Derek C.", txt: "Homeowner without renters bundle — savings opportunity", risk: "opp", min: "22m" },
];

const SMS_THREAD = [
  { me: false, txt: "Hi, I added a new car last week — do I have proof of insurance yet?", t: "9:42a" },
  { me: true, txt: "Hi Robert! I see the 2024 Honda CR-V on your policy. I still need the signed application before I can issue proof.", t: "9:44a" },
  { me: false, txt: "Got it. Where do I sign?", t: "9:45a" },
  { me: true, txt: "Sending a secure e-sign link now. Once that's back I'll text your ID card. \uD83D\uDC4D", t: "9:46a" },
];

const VOICEMAILS = [
  { from: "Diana Whitfield", num: "(602) 555-0184", t: "8:21a", len: "0:38", txt: "Calling about my homeowners renewal premium going up — please call back." },
  { from: "Auto-Owners Carrier", num: "(800) 555-2210", t: "Yesterday", len: "1:12", txt: "Underwriting needs the updated VIN and garaging address for policy 88-2241." },
];

// ---------- Small UI helpers ----------
const statusMap = {
  available: { c: C.green, l: "Available" },
  oncall: { c: C.teal, l: "On call" },
  wrapup: { c: C.amber, l: "Wrap-up" },
  break: { c: C.faint, l: "Break" },
  offline: { c: "#C2BCAD", l: "Offline" },
};

function Dot({ color, pulse }) {
  return <span style={{ width: 9, height: 9, borderRadius: 99, background: color, display: "inline-block", animation: pulse ? "pulse 1.8s infinite" : "none" }} />;
}

function Card({ children, style, className = "" }) {
  return (
    <div className={`wc-fade ${className}`} style={{ background: C.card, border: `1px solid ${C.line}`, borderRadius: 16, ...style }}>
      {children}
    </div>
  );
}

function SectionTitle({ icon: Icon, children, right }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 9, marginBottom: 14 }}>
      {Icon && <Icon size={16} color={C.teal} strokeWidth={2.2} />}
      <span style={{ fontWeight: 700, fontSize: 13, letterSpacing: ".04em", textTransform: "uppercase", color: C.ink }}>{children}</span>
      <div style={{ flex: 1 }} />
      {right}
    </div>
  );
}

const mono = { fontFamily: "'IBM Plex Mono', monospace" };

// ================= AGENT =================
function AgentView() {
  const [status, setStatus] = useState("oncall");
  const [secs, setSecs] = useState(252);
  const [muted, setMuted] = useState(false);
  const [hold, setHold] = useState(false);
  const [tab, setTab] = useState("call");
  const [checks, setChecks] = useState({ vin: true, drivers: true, garage: false, usage: false, pay: false, sign: false });
  const callActive = status === "oncall";

  useEffect(() => {
    if (!callActive || hold) return;
    const id = setInterval(() => setSecs((s) => s + 1), 1000);
    return () => clearInterval(id);
  }, [callActive, hold]);

  const mm = String(Math.floor(secs / 60)).padStart(2, "0");
  const ss = String(secs % 60).padStart(2, "0");

  const checklist = [
    { k: "vin", l: "VIN — 2024 Honda CR-V" },
    { k: "drivers", l: "Listed drivers confirmed" },
    { k: "garage", l: "Garaging address verified" },
    { k: "usage", l: "Vehicle usage & mileage" },
    { k: "pay", l: "Payment method on file" },
    { k: "sign", l: "Signed application received" },
  ];
  const done = Object.values(checks).filter(Boolean).length;

  return (
    <div style={{ display: "grid", gridTemplateColumns: "300px 1fr 340px", gap: 18 }}>
      {/* Softphone */}
      <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
        <Card style={{ padding: 18 }}>
          <SectionTitle icon={Headphones}>My Status</SectionTitle>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            {["available", "oncall", "wrapup", "break"].map((s) => {
              const on = status === s;
              return (
                <button key={s} className="wc-btn" onClick={() => setStatus(s)}
                  style={{ padding: "9px 8px", borderRadius: 10, fontSize: 12.5, fontWeight: 600,
                    background: on ? C.ink : "#F4F2EA", color: on ? "#fff" : C.mute,
                    display: "flex", alignItems: "center", gap: 7, justifyContent: "center" }}>
                  <Dot color={statusMap[s].c} pulse={on && s !== "break"} /> {statusMap[s].l}
                </button>
              );
            })}
          </div>
        </Card>

        <Card style={{ padding: 18 }}>
          <SectionTitle icon={Grid3x3}>Dialer</SectionTitle>
          <div style={{ background: C.paper, borderRadius: 12, padding: "12px 14px", marginBottom: 12, ...mono, fontSize: 18, color: C.ink, letterSpacing: ".04em" }}>
            (480) 555&nbsp;‹
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8 }}>
            {["1", "2", "3", "4", "5", "6", "7", "8", "9", "＊", "0", "#"].map((d) => (
              <button key={d} className="wc-btn" style={{ padding: "13px 0", borderRadius: 10, background: "#F4F2EA", fontSize: 16, fontWeight: 600, color: C.ink, ...mono }}>{d}</button>
            ))}
          </div>
          <button className="wc-btn" style={{ marginTop: 12, width: "100%", padding: "12px 0", borderRadius: 11, background: C.green, color: "#fff", fontWeight: 700, fontSize: 14, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
            <PhoneOutgoing size={16} /> Call
          </button>
        </Card>

        <Card style={{ padding: 18 }}>
          <SectionTitle icon={Activity}>My Queue Today</SectionTitle>
          {[["Calls handled", "27"], ["Avg handle time", "5:48"], ["Texts sent", "41"], ["Voicemails", "3"]].map(([k, v]) => (
            <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "7px 0", borderBottom: `1px solid ${C.line}`, fontSize: 13 }}>
              <span style={{ color: C.mute }}>{k}</span>
              <span style={{ fontWeight: 700, color: C.ink, ...mono }}>{v}</span>
            </div>
          ))}
        </Card>
      </div>

      {/* Center: live call + AI workflow */}
      <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
        <Card style={{ padding: 0, overflow: "hidden", border: callActive ? `1px solid ${C.teal}` : `1px solid ${C.line}` }}>
          <div style={{ background: `linear-gradient(120deg, ${C.ink}, ${C.ink2})`, padding: "20px 22px", color: "#fff" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
              <div style={{ width: 52, height: 52, borderRadius: 14, background: "rgba(255,255,255,.12)", display: "flex", alignItems: "center", justifyContent: "center", animation: callActive && !hold ? "ringpulse 2s infinite" : "none" }}>
                <PhoneIncoming size={22} color="#fff" />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 18, fontWeight: 700, fontFamily: "'Bricolage Grotesque'" }}>Robert Castillo</div>
                <div style={{ fontSize: 13, color: "#A9BAC4", ...mono }}>(602) 555-0147 · Inbound · Sales</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontSize: 22, fontWeight: 700, ...mono }}>{callActive ? `${mm}:${ss}` : "—:—"}</div>
                <div style={{ fontSize: 11, color: "#A9BAC4" }}>{hold ? "On hold" : callActive ? "Connected" : "Idle"}</div>
              </div>
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 16, flexWrap: "wrap" }}>
              {[{ t: "Auto · Active", c: C.green }, { t: "Home · Active", c: C.green }, { t: "Customer since 2019", c: "rgba(255,255,255,.5)" }].map((p) => (
                <span key={p.t} style={{ fontSize: 11.5, padding: "4px 10px", borderRadius: 99, background: "rgba(255,255,255,.1)", color: "#fff", display: "inline-flex", alignItems: "center", gap: 6 }}>
                  <span style={{ width: 6, height: 6, borderRadius: 99, background: p.c }} /> {p.t}
                </span>
              ))}
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 18 }}>
              <CallCtl icon={muted ? MicOff : Mic} label={muted ? "Unmute" : "Mute"} active={muted} onClick={() => setMuted(!muted)} />
              <CallCtl icon={Pause} label={hold ? "Resume" : "Hold"} active={hold} onClick={() => setHold(!hold)} />
              <CallCtl icon={ArrowRightLeft} label="Transfer" />
              <CallCtl icon={Volume2} label="Keypad" />
              <button className="wc-btn" onClick={() => setStatus("wrapup")} style={{ flex: 1, background: C.red, color: "#fff", borderRadius: 11, fontWeight: 700, fontSize: 13, display: "flex", alignItems: "center", justifyContent: "center", gap: 7 }}>
                <Phone size={15} style={{ transform: "rotate(135deg)" }} /> End
              </button>
            </div>
          </div>

          {/* AI live workflow */}
          <div style={{ padding: "18px 22px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
              <Sparkles size={16} color={C.teal} />
              <span style={{ fontWeight: 700, fontSize: 13, color: C.ink }}>AI Workflow · Add-a-Car</span>
              <span style={{ marginLeft: "auto", fontSize: 11.5, color: C.mute, ...mono }}>{done}/6 captured</span>
            </div>
            <div style={{ height: 6, background: C.paper, borderRadius: 99, overflow: "hidden", marginBottom: 14 }}>
              <div style={{ height: "100%", width: `${(done / 6) * 100}%`, background: C.teal, borderRadius: 99, transition: "width .4s ease" }} />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              {checklist.map((it) => {
                const on = checks[it.k];
                return (
                  <button key={it.k} className="wc-btn" onClick={() => setChecks((c) => ({ ...c, [it.k]: !c[it.k] }))}
                    style={{ display: "flex", alignItems: "center", gap: 9, padding: "10px 12px", borderRadius: 10, textAlign: "left",
                      background: on ? C.tealSoft : "#F8F7F1", border: `1px solid ${on ? "#BFE0D6" : C.line}` }}>
                    {on ? <CheckCircle2 size={17} color={C.teal} /> : <Circle size={17} color={C.faint} />}
                    <span style={{ fontSize: 12.5, color: on ? C.ink : C.mute, fontWeight: on ? 600 : 500 }}>{it.l}</span>
                  </button>
                );
              })}
            </div>

            {!checks.sign && (
              <div className="wc-fade" style={{ marginTop: 14, padding: "11px 13px", background: C.redSoft, border: `1px solid #F3B5B5`, borderRadius: 10, display: "flex", gap: 10, alignItems: "flex-start" }}>
                <AlertTriangle size={17} color={C.red} style={{ flexShrink: 0, marginTop: 1 }} />
                <span style={{ fontSize: 12.5, color: "#B83A3A", lineHeight: 1.5 }}>
                  <b>Compliance hold:</b> Do not issue or declare proof of insurance until the signed application is received. Sales credit is blocked until this clears.
                </span>
              </div>
            )}
            <div style={{ marginTop: 10, padding: "11px 13px", background: C.amberSoft, border: `1px solid #BCE4F5`, borderRadius: 10, display: "flex", gap: 10, alignItems: "flex-start" }}>
              <TrendingUp size={17} color={C.amber} style={{ flexShrink: 0, marginTop: 1 }} />
              <span style={{ fontSize: 12.5, color: "#0A5980", lineHeight: 1.5 }}>
                <b>Cross-sell:</b> Customer mentioned a teen driver moving in. Suggest umbrella coverage and a renters quote.
              </span>
            </div>
          </div>
        </Card>

        <Card style={{ padding: 18 }}>
          <SectionTitle icon={FileText}>Live Transcript</SectionTitle>
          <div className="wc-scroll" style={{ maxHeight: 130, overflowY: "auto", display: "flex", flexDirection: "column", gap: 10 }}>
            {[["Robert", "I just want to make sure the new CR-V is covered before my daughter drives it."], ["You", "Absolutely — I've added the vehicle, I just need your signature on the application."], ["Robert", "Okay. Can my daughter be added too? She just got her license."]].map(([w, t], i) => (
              <div key={i} style={{ fontSize: 13, lineHeight: 1.5 }}>
                <span style={{ fontWeight: 700, color: w === "You" ? C.teal : C.ink }}>{w}: </span>
                <span style={{ color: C.mute }}>{t}</span>
              </div>
            ))}
            <div style={{ fontSize: 12, color: C.faint, animation: "shimmer 1.6s infinite", ...mono }}>● transcribing…</div>
          </div>
        </Card>
      </div>

      {/* Right: AI summary + tabs */}
      <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
        <Card style={{ padding: 0, overflow: "hidden" }}>
          <div style={{ display: "flex", borderBottom: `1px solid ${C.line}` }}>
            {[["call", "AI Summary", Sparkles], ["sms", "Texts", MessageSquare], ["vm", "Voicemail", Voicemail]].map(([k, l, Ic]) => (
              <button key={k} className="wc-btn" onClick={() => setTab(k)}
                style={{ flex: 1, padding: "12px 4px", background: tab === k ? C.card : "#F8F7F1", color: tab === k ? C.teal : C.mute, fontWeight: 600, fontSize: 12, display: "flex", flexDirection: "column", alignItems: "center", gap: 4, borderBottom: tab === k ? `2px solid ${C.teal}` : "2px solid transparent" }}>
                <Ic size={15} /> {l}
              </button>
            ))}
          </div>
          <div style={{ padding: 18 }}>
            {tab === "call" && (
              <div className="wc-fade">
                <p style={{ fontSize: 13, lineHeight: 1.6, color: C.ink, margin: "0 0 14px" }}>
                  Robert called to confirm coverage on a newly added <b>2024 Honda CR-V</b> and asked to add his teen daughter as a driver. Vehicle added; signed application still pending before proof can issue.
                </p>
                <div style={{ fontWeight: 700, fontSize: 12, textTransform: "uppercase", letterSpacing: ".04em", color: C.mute, marginBottom: 8 }}>Action Items</div>
                {["Send e-sign link for application", "Add daughter as listed driver (pending DL #)", "Quote umbrella + renters bundle", "Issue ID card after signature"].map((a, i) => (
                  <div key={i} style={{ display: "flex", gap: 9, alignItems: "flex-start", padding: "7px 0", borderBottom: `1px solid ${C.line}`, fontSize: 12.5 }}>
                    <Circle size={14} color={C.teal} style={{ marginTop: 2, flexShrink: 0 }} />
                    <span style={{ color: C.ink }}>{a}</span>
                  </div>
                ))}
                <div style={{ marginTop: 14, fontWeight: 700, fontSize: 12, textTransform: "uppercase", letterSpacing: ".04em", color: C.mute, marginBottom: 8 }}>Disposition</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 7 }}>
                  {["Quote", "Follow-up", "Documentation needed", "Cross-sell"].map((d, i) => (
                    <span key={d} style={{ fontSize: 11.5, padding: "5px 11px", borderRadius: 99, fontWeight: 600,
                      background: i === 2 ? C.ink : "#F4F2EA", color: i === 2 ? "#fff" : C.mute, cursor: "pointer" }}>{d}</span>
                  ))}
                </div>
              </div>
            )}
            {tab === "sms" && (
              <div className="wc-fade" style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {SMS_THREAD.map((m, i) => (
                  <div key={i} style={{ alignSelf: m.me ? "flex-end" : "flex-start", maxWidth: "82%" }}>
                    <div style={{ background: m.me ? C.teal : "#F1EFE7", color: m.me ? "#fff" : C.ink, padding: "9px 12px", borderRadius: 13, fontSize: 12.5, lineHeight: 1.45 }}>{m.txt}</div>
                    <div style={{ fontSize: 10.5, color: C.faint, marginTop: 3, textAlign: m.me ? "right" : "left", ...mono }}>{m.t}</div>
                  </div>
                ))}
                <div style={{ display: "flex", gap: 7, marginTop: 6 }}>
                  <div style={{ flex: 1, background: C.paper, borderRadius: 10, padding: "9px 12px", fontSize: 12.5, color: C.faint }}>Type a message…</div>
                  <button className="wc-btn" style={{ background: C.teal, color: "#fff", borderRadius: 10, padding: "0 13px", fontWeight: 600, fontSize: 12.5 }}>Send</button>
                </div>
              </div>
            )}
            {tab === "vm" && (
              <div className="wc-fade" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {VOICEMAILS.map((v, i) => (
                  <div key={i} style={{ borderBottom: `1px solid ${C.line}`, paddingBottom: 12 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <span style={{ fontWeight: 700, fontSize: 13, color: C.ink }}>{v.from}</span>
                      <span style={{ fontSize: 11, color: C.faint, ...mono }}>{v.t} · {v.len}</span>
                    </div>
                    <div style={{ fontSize: 11.5, color: C.faint, marginBottom: 6, ...mono }}>{v.num}</div>
                    <p style={{ fontSize: 12.5, color: C.mute, lineHeight: 1.5, margin: 0 }}>{v.txt}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}

function CallCtl({ icon: Icon, label, active, onClick }) {
  return (
    <button className="wc-btn" onClick={onClick} style={{ background: active ? "#fff" : "rgba(255,255,255,.1)", color: active ? C.ink : "#fff", borderRadius: 11, padding: "9px 12px", display: "flex", flexDirection: "column", alignItems: "center", gap: 4, fontSize: 10.5, fontWeight: 600, minWidth: 56 }}>
      <Icon size={16} /> {label}
    </button>
  );
}

// ================= MANAGER =================
function ManagerView() {
  const kpis = [
    { l: "Calls today", v: "318", sub: "+12% vs avg", icon: PhoneCall, c: C.teal },
    { l: "Missed", v: "14", sub: "4.4% miss rate", icon: PhoneMissed, c: C.red },
    { l: "Active now", v: "9", sub: "across 4 queues", icon: Activity, c: C.green },
    { l: "Avg answer", v: "0:18", sub: "SLA target 0:30", icon: Clock, c: C.teal },
  ];
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14 }}>
        {kpis.map((k, i) => (
          <Card key={k.l} style={{ padding: 18, animationDelay: `${i * 60}ms` }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <span style={{ fontSize: 12.5, color: C.mute, fontWeight: 600 }}>{k.l}</span>
              <k.icon size={17} color={k.c} />
            </div>
            <div style={{ fontSize: 32, fontWeight: 700, color: C.ink, marginTop: 8, fontFamily: "'Bricolage Grotesque'", ...mono }}>{k.v}</div>
            <div style={{ fontSize: 11.5, color: C.faint, marginTop: 2 }}>{k.sub}</div>
          </Card>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 18 }}>
        {/* Live agents */}
        <Card style={{ padding: 18 }}>
          <SectionTitle icon={Users} right={<span style={{ fontSize: 11.5, color: C.faint }}>Listen · Whisper · Barge</span>}>Live Agent Wallboard</SectionTitle>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            {AGENTS.map((a) => {
              const sm = statusMap[a.s];
              return (
                <div key={a.n} className="wc-row" style={{ display: "flex", alignItems: "center", gap: 11, padding: "10px 12px", border: `1px solid ${C.line}`, borderRadius: 11 }}>
                  <Dot color={sm.c} pulse={a.s === "oncall"} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 600, fontSize: 13, color: C.ink, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{a.n}</div>
                    <div style={{ fontSize: 11, color: C.faint }}>{a.t} · {a.lang} · {sm.l}{a.dur ? ` ${a.dur}` : ""}</div>
                  </div>
                  {a.s === "oncall" && <Headphones size={14} color={C.teal} />}
                </div>
              );
            })}
          </div>
        </Card>

        {/* Queues */}
        <Card style={{ padding: 18 }}>
          <SectionTitle icon={Languages}>Queues & SLA</SectionTitle>
          {QUEUES.map((q) => (
            <div key={q.name} style={{ marginBottom: 14 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 5 }}>
                <span style={{ fontWeight: 600, color: C.ink }}>{q.name}</span>
                <span style={{ color: C.mute, ...mono }}>{q.waiting} waiting · longest {q.longest}</span>
              </div>
              <div style={{ height: 7, background: C.paper, borderRadius: 99, overflow: "hidden" }}>
                <div style={{ height: "100%", width: `${q.sla}%`, background: q.color, borderRadius: 99 }} />
              </div>
              <div style={{ fontSize: 11, color: C.faint, marginTop: 3, ...mono }}>{q.sla}% within SLA</div>
            </div>
          ))}
        </Card>
      </div>

      {/* AI flags */}
      <Card style={{ padding: 18 }}>
        <SectionTitle icon={Shield} right={<span style={{ fontSize: 11.5, color: C.faint }}>Auto-generated from call AI</span>}>Compliance & Sales Flags</SectionTitle>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          {FLAGS.map((f, i) => {
            const isComp = f.type === "compliance";
            return (
              <div key={i} style={{ display: "flex", gap: 12, padding: 14, borderRadius: 12, background: isComp ? C.redSoft : C.amberSoft, border: `1px solid ${isComp ? "#F3B5B5" : "#BCE4F5"}` }}>
                {isComp ? <Shield size={18} color={C.red} style={{ flexShrink: 0, marginTop: 1 }} /> : <Star size={18} color={C.amber} style={{ flexShrink: 0, marginTop: 1 }} />}
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
                    <span style={{ fontWeight: 700, fontSize: 12, color: isComp ? "#B83A3A" : "#0A5980", textTransform: "uppercase", letterSpacing: ".03em" }}>{isComp ? "Compliance risk" : "Sales opportunity"}</span>
                    <span style={{ fontSize: 11, color: C.faint, ...mono }}>{f.who} · {f.min}</span>
                  </div>
                  <p style={{ fontSize: 12.5, color: C.ink, margin: 0, lineHeight: 1.45 }}>{f.txt}</p>
                </div>
                <ChevronRight size={16} color={C.faint} style={{ alignSelf: "center" }} />
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}

// ================= ADMIN =================
function AdminView() {
  const [tab, setTab] = useState("numbers");
  const tabs = [["numbers", "Numbers & Routing", Hash], ["teams", "Users & Teams", Users], ["templates", "Text Templates", MessageSquare], ["ai", "AI Prompts", Sparkles], ["rec", "Recording", Mic]];
  return (
    <Card style={{ padding: 0, overflow: "hidden" }}>
      <div style={{ display: "flex", borderBottom: `1px solid ${C.line}`, overflowX: "auto" }} className="wc-scroll">
        {tabs.map(([k, l, Ic]) => (
          <button key={k} className="wc-btn" onClick={() => setTab(k)}
            style={{ padding: "14px 18px", whiteSpace: "nowrap", background: tab === k ? C.card : "#F8F7F1", color: tab === k ? C.teal : C.mute, fontWeight: 600, fontSize: 13, display: "flex", alignItems: "center", gap: 7, borderBottom: tab === k ? `2px solid ${C.teal}` : "2px solid transparent" }}>
            <Ic size={15} /> {l}
          </button>
        ))}
      </div>
      <div style={{ padding: 22 }} className="wc-fade">
        {tab === "numbers" && (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
            <thead>
              <tr style={{ textAlign: "left", color: C.mute, fontSize: 11.5, textTransform: "uppercase", letterSpacing: ".04em" }}>
                <th style={{ padding: "0 0 12px" }}>Number</th><th>Label</th><th>Routes to</th><th>Hours</th><th>Status</th>
              </tr>
            </thead>
            <tbody>
              {[["(480) 555-0100", "Main line", "Sales ring group", "Business hrs → VM", "A2P verified"],
                ["(480) 555-0142", "Service queue", "Service skills route", "24/7 with failover", "A2P verified"],
                ["(602) 555-0190", "Línea en Español", "Spanish-speaking agents", "Business hrs", "A2P verified"],
                ["(480) 555-0177", "Commercial", "Commercial queue", "Business hrs → on-call", "Porting"]].map((r, i) => (
                <tr key={i} className="wc-row" style={{ borderTop: `1px solid ${C.line}` }}>
                  <td style={{ padding: "12px 0", ...mono, color: C.ink, fontWeight: 600 }}>{r[0]}</td>
                  <td style={{ color: C.ink }}>{r[1]}</td>
                  <td style={{ color: C.mute }}>{r[2]}</td>
                  <td style={{ color: C.mute }}>{r[3]}</td>
                  <td><span style={{ fontSize: 11.5, padding: "3px 9px", borderRadius: 99, fontWeight: 600, background: r[4] === "Porting" ? C.amberSoft : "#E4F7EE", color: r[4] === "Porting" ? C.amber : C.green }}>{r[4]}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {tab === "teams" && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 14 }}>
            {[["Sales", 6, C.teal], ["Service", 9, C.amber], ["Commercial", 4, C.green], ["Español", 5, C.teal], ["Managers", 3, C.ink], ["Admins", 2, C.mute]].map(([t, n, c]) => (
              <div key={t} style={{ padding: 16, border: `1px solid ${C.line}`, borderRadius: 12 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 9, marginBottom: 8 }}>
                  <div style={{ width: 30, height: 30, borderRadius: 8, background: c, display: "flex", alignItems: "center", justifyContent: "center" }}><UserCheck size={15} color="#fff" /></div>
                  <span style={{ fontWeight: 700, color: C.ink }}>{t}</span>
                </div>
                <div style={{ fontSize: 13, color: C.mute }}>{n} members · role-based access</div>
              </div>
            ))}
          </div>
        )}
        {tab === "templates" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {[["Missed-call text-back", "Sorry we missed you at We Insure Things! Reply here and an agent will help. Reply STOP to opt out."],
              ["After-hours auto-reply", "Thanks for texting WIT. We're open M–F 8a–6p. For claims, call your carrier's 24/7 line."],
              ["Proof of insurance", "Hi {name}, your ID card is attached. Coverage effective {date}. Questions? Just reply."],
              ["Renewal reminder", "Hi {name}, your {policy} renews {date}. Want a quick review to check for savings?"]].map(([t, b], i) => (
              <div key={i} style={{ padding: 14, border: `1px solid ${C.line}`, borderRadius: 11 }}>
                <div style={{ fontWeight: 700, fontSize: 13, color: C.ink, marginBottom: 4 }}>{t}</div>
                <div style={{ fontSize: 12.5, color: C.mute, lineHeight: 1.5 }}>{b}</div>
              </div>
            ))}
          </div>
        )}
        {tab === "ai" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {[["Add-a-Car workflow", "Prompt agent to collect VIN, drivers, garaging, usage, payment, signature. Block proof until signed app received.", true],
              ["Cancellation / retention", "Detect: cancel, complaint, DOI, attorney, lawsuit. Flag manager, prompt remarketing + replacement-coverage warning.", true],
              ["Cross-sell prompts", "Surface renters, home, umbrella, life opportunities based on conversation context.", true],
              ["Compliance documentation", "Require supporting docs before declaring proof or scrubbing violations. Store to customer record.", true]].map(([t, b, on], i) => (
              <div key={i} style={{ display: "flex", gap: 14, padding: 14, border: `1px solid ${C.line}`, borderRadius: 11, alignItems: "flex-start" }}>
                <Sparkles size={17} color={C.teal} style={{ marginTop: 2, flexShrink: 0 }} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: 13, color: C.ink }}>{t}</div>
                  <div style={{ fontSize: 12.5, color: C.mute, lineHeight: 1.5, marginTop: 3 }}>{b}</div>
                </div>
                <div style={{ width: 38, height: 22, borderRadius: 99, background: C.teal, position: "relative", flexShrink: 0 }}>
                  <span style={{ position: "absolute", top: 2, right: 2, width: 18, height: 18, borderRadius: 99, background: "#fff" }} />
                </div>
              </div>
            ))}
          </div>
        )}
        {tab === "rec" && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
            {[["Call recording", "Enabled for all inbound/outbound", C.teal],
              ["Consent disclosure", "Two-party states: auto-play notice", C.teal],
              ["Retention period", "13 months, then auto-purge", C.ink],
              ["Transcript access", "Managers + admins · audit-logged", C.ink],
              ["Storage", "Cloudflare R2 · encrypted at rest", C.ink],
              ["AI summaries", "Marked assistive · human review on", C.amber]].map(([t, b, c], i) => (
              <div key={i} style={{ padding: 16, border: `1px solid ${C.line}`, borderRadius: 12 }}>
                <div style={{ fontWeight: 700, fontSize: 13, color: C.ink, marginBottom: 5 }}>{t}</div>
                <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                  <Dot color={c} /><span style={{ fontSize: 12.5, color: C.mute }}>{b}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Card>
  );
}

// ================= SHELL =================
export default function WITConnect() {
  const [view, setView] = useState("agent");
  const nav = [
    { k: "agent", l: "Agent", icon: Headphones, sub: "My calls & texts" },
    { k: "manager", l: "Manager", icon: Activity, sub: "Live operations" },
    { k: "admin", l: "Admin", icon: Settings, sub: "Config & routing" },
  ];
  const titles = { agent: "Agent Workspace", manager: "Operations Dashboard", admin: "System Administration" };

  return (
    <div className="wc" style={{ fontFamily: "'IBM Plex Sans', sans-serif", background: C.paper, minHeight: "100vh", display: "flex", color: C.ink }}>
      <style>{FONTS}</style>

      {/* Sidebar */}
      <aside style={{ width: 232, background: `linear-gradient(180deg, ${C.ink}, ${C.ink2})`, color: "#fff", padding: "22px 16px", display: "flex", flexDirection: "column", flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0 6px 22px" }}>
          <div style={{ width: 38, height: 38, borderRadius: 11, background: C.teal, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontFamily: "'Bricolage Grotesque'", fontSize: 17 }}>W</div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 16, fontFamily: "'Bricolage Grotesque'", lineHeight: 1 }}>WIT Connect</div>
            <div style={{ fontSize: 10.5, color: "#7E94A1", letterSpacing: ".05em" }}>WE INSURE THINGS</div>
          </div>
        </div>

        {nav.map((n) => {
          const on = view === n.k;
          return (
            <button key={n.k} className="wc-btn wc-nav" onClick={() => setView(n.k)}
              style={{ display: "flex", alignItems: "center", gap: 12, padding: "11px 12px", borderRadius: 11, marginBottom: 4, textAlign: "left", background: on ? C.teal : "transparent", color: "#fff" }}>
              <n.icon size={18} color={on ? "#fff" : "#9DB1BD"} />
              <div>
                <div style={{ fontWeight: 600, fontSize: 14 }}>{n.l}</div>
                <div style={{ fontSize: 11, color: on ? "rgba(255,255,255,.7)" : "#7E94A1" }}>{n.sub}</div>
              </div>
            </button>
          );
        })}

        <div style={{ flex: 1 }} />
        <div style={{ padding: "13px 12px", background: "rgba(255,255,255,.06)", borderRadius: 12, fontSize: 11.5, color: "#9DB1BD", lineHeight: 1.5 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 6, color: "#fff", fontWeight: 600 }}>
            <Dot color={C.green} pulse /> System healthy
          </div>
          Twilio voice · SMS · AI online. Pilot team: Sales.
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 14, padding: "0 6px" }}>
          <div style={{ width: 32, height: 32, borderRadius: 99, background: C.teal, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700 }}>MV</div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600 }}>Marisol Vega</div>
            <div style={{ fontSize: 10.5, color: "#7E94A1" }}>Sales · EN/ES</div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
        <header style={{ display: "flex", alignItems: "center", gap: 16, padding: "16px 26px", borderBottom: `1px solid ${C.line}`, background: "rgba(245,243,236,.8)", backdropFilter: "blur(6px)" }}>
          <div>
            <h1 style={{ fontSize: 21, fontWeight: 700, margin: 0, fontFamily: "'Bricolage Grotesque'" }}>{titles[view]}</h1>
            <div style={{ fontSize: 12, color: C.mute }}>Friday, May 31 · 9:46 AM MST</div>
          </div>
          <div style={{ flex: 1 }} />
          <div style={{ display: "flex", alignItems: "center", gap: 9, background: C.card, border: `1px solid ${C.line}`, borderRadius: 10, padding: "8px 12px", color: C.faint, fontSize: 13, minWidth: 200 }}>
            <Search size={15} /> Search customers, calls…
          </div>
          <button className="wc-btn" style={{ width: 38, height: 38, borderRadius: 10, background: C.card, border: `1px solid ${C.line}`, display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
            <Bell size={17} color={C.ink} />
            <span style={{ position: "absolute", top: 8, right: 9, width: 7, height: 7, borderRadius: 99, background: C.red }} />
          </button>
        </header>

        <div className="wc-scroll" style={{ padding: 26, overflowY: "auto", flex: 1 }}>
          {view === "agent" && <AgentView />}
          {view === "manager" && <ManagerView />}
          {view === "admin" && <AdminView />}
          <div style={{ textAlign: "center", fontSize: 11.5, color: C.faint, marginTop: 28, lineHeight: 1.5 }}>
            WIT Connect prototype · mock data for demonstration · not connected to live Twilio or customer records
          </div>
        </div>
      </main>
    </div>
  );
}
