# WIT Connect — Claude Guidelines

This is the WIT Connect codebase: a custom phone, SMS, AI, and contact-center
platform for We Insure Things (WIT), an independent insurance agency.

## Project context

- **Backend**: Node.js / Express (ESM), `src/` folder, Twilio Voice SDK
- **Database**: PostgreSQL — schema in `02-database/wit_connect_schema.sql`
- **Frontend**: React (`.jsx`), WIT brand palette (see below), IBM Plex Sans / Bricolage Grotesque fonts
- **AI pipeline**: Prompt library in `04-ai/`, outputs must match schema enums
- **API contract**: `05-api/wit_connect_api_route_map.md` — follow this spec exactly when adding routes

## WIT brand palette

```
WIT Blue (primary):  #00AEEF
Deep WIT Blue:       #007EAE
Ink / Navy Black:    #06121D
White:               #FFFFFF
Soft background:     #F4F8FB
Muted text:          #6B7280
Success green:       #33D17A
Alert red:           #FF6868
```

## Coding standards

- **ESM modules** throughout (`import/export`, not `require`)
- **Async/await** over `.then()` chains
- **Parameterized queries** only — never string-interpolate SQL
- **Best-effort DB writes**: a database failure must never break a live Twilio TwiML response
- All webhook routes validate the `X-Twilio-Signature` header in production
- Secrets via environment variables only — never hardcoded, never committed
- Error responses follow `{ "error": { "code": "string", "message": "string" } }`

## Insurance-specific rules (critical)

- Never suggest issuing or declaring proof of insurance without a signed application
- Never confirm coverage is bound, claim outcomes, or policy effective dates
- Any call mentioning "cancel", "attorney", "DOI", "lawsuit" must trigger an `ai_flags` row
- Compliance flags always take priority — surface them even if everything else looks fine
- AI summaries are stored with `is_human_reviewed = false`; mark them assistive in all UI copy

## Schema conventions

- UUID primary keys via `gen_random_uuid()`
- `created_at` / `updated_at` on all mutable tables; `updated_at` maintained by trigger
- Twilio SIDs stored alongside internal UUIDs (e.g. `twilio_call_sid`, `twilio_recording_sid`)
- Enum values are exact — check `wit_connect_schema.sql` before adding or comparing

## What NOT to do

- Do not add `console.log` with PII (phone numbers, names, account details)
- Do not drop `retention_until` or `consent` fields from recording/transcript writes
- Do not change the API route shapes in `05-api/` without a corresponding schema migration
- Do not introduce `require()` — this is an ESM project
